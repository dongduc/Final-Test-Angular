import { Component } from '@angular/core';
import { VideoService } from './services/video.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FinalTest-BinhPT10';
  constructor(
    private videoService: VideoService
  ){}
  save(page, deb, key) {
    //this.videoService.KEY = key;
    this.videoService.deb = deb;
    this.videoService.page = page;
  }
}
