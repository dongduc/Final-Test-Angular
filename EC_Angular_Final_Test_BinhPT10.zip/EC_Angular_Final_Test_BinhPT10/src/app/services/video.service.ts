import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Video } from '../models/video.class';

@Injectable({
  providedIn: 'root'
})
export class VideoService {
  public KEY = 'AIzaSyBxWxweg3RpzWwAxmWdEZnMDT-sfpSHMLM';
  public page: number;
  public deb: number = 1000;
  constructor(
    private httpClient: HttpClient
  ) {
    this.page = 10;
  }
  getListVideo(nameVideo: string): Observable<Video> {
    const url = 'https://www.googleapis.com/youtube/v3/search';
    return this.httpClient.get<Video>(url, {params: {
      q: nameVideo,
      key: this.KEY,
      part: 'snippet',
      maxResults: '30',
      type: 'video'
    }});
  }
  getListVideoSort(nameVideo: string, sort: string): Observable<Video> {
    const url = 'https://www.googleapis.com/youtube/v3/search';
    return this.httpClient.get<Video>(url, {params: {
      q: nameVideo,
      key: this.KEY,
      part: 'snippet',
      maxResults: '30',
      type: 'video',
      order: sort
    }});
  }
  getVideoById(id: string): Observable<Video> {
    const url = 'https://www.googleapis.com/youtube/v3/videos';
    return this.httpClient.get<Video>(url, {params: {
      id: id,
      part: 'snippet,contentDetails,statistics,status',
      key: this.KEY,
      type: 'video'
    }});
  }
  getListVideoByDate(nameVideo: string, fromDate, toDate): Observable<Video> {
    const url = 'https://www.googleapis.com/youtube/v3/search';
    return this.httpClient.get<Video>(url, {params: {
      q: nameVideo,
      key: this.KEY,
      part: 'snippet',
      maxResults: '30',
      type: 'video',
      publishedAfter: fromDate,
      publishedBefore: toDate
    }});
  }
}
