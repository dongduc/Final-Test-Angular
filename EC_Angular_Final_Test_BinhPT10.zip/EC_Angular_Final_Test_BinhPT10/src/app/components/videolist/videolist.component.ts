import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Video } from '../../models/video.class';
import { VideoService } from '../../services/video.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-videolist',
  templateUrl: './videolist.component.html',
  styleUrls: ['./videolist.component.css']
})
export class VideolistComponent implements OnInit {
  private videos: Video[] = [];
  private page = 1;
  public subscription: Subscription;
  private name: string;
  private video: Video;
  constructor(
    private activatedRouter: ActivatedRoute,
    private videoService: VideoService,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {
  }

  ngOnInit() {
    this.getListVideo();
    this.getListSort();
    this.getListFilterDate();
  }
  getListVideo() {
    return this.activatedRouter.params.subscribe(x => {
      this.name = x.name;
      this.subscription = this.videoService.getListVideo(this.name).subscribe(data => {
        this.videos = data.items;
      });
    });
  }
  getListSort() {
    this.activatedRouter.queryParams.subscribe(param => {
      if (param['sort']) {
        this.subscription = this.videoService.getListVideoSort(localStorage.getItem('keySearch'), param['sort']).subscribe(data => {
          this.videos = data.items;
          console.log(this.videos);
        });
      }
    });
  }
  private baseUrl = 'https://www.youtube.com/embed/';
  private title: string;
  private description: string;
  private channelTitle: string;
  public url: SafeResourceUrl = this.sanitizer.bypassSecurityTrustResourceUrl('');
  public id: string;
  showDetail(id: string) {
    this.subscription = this.videoService.getVideoById(id).subscribe(data => {
      console.log(data);
      this.title = data.items[0].snippet.title;
      this.description = data.items[0].snippet.description;
      this.channelTitle = data.items[0].snippet.channelTitle;
      this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.baseUrl + id);
      this.id= id;
    });
  }
  getListFilterDate() {
    this.activatedRouter.queryParams.subscribe(param => {
      if (param['fromDate']) {
        this.subscription = this.videoService.getListVideoByDate(localStorage.getItem('keySearch'), param['fromDate'], param['toDate']).subscribe(data => {
          this.videos = data.items;
          console.log(this.videos);
        });
      }
    });
  }
  closeVideo() {
    this.showDetail(this.id);
  }
}
