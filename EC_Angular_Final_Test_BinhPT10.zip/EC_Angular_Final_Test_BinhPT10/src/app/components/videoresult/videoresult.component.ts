import { Component, OnInit } from '@angular/core';
import { VideoService } from '../../services/video.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-videoresult',
  templateUrl: './videoresult.component.html',
  styleUrls: ['./videoresult.component.css']
})
export class VideoresultComponent implements OnInit {
  private fromDate: Date;
  private toDate: Date;
  constructor(
    private videoService: VideoService,
    private router: Router
  ) {
    this.fromDate = null;
    this.toDate = null;
   }

  ngOnInit() {
  }
  onSort(value) {
    let sort: string;
    let url = `/video/search/${localStorage.getItem('keySearch')}`;
    if (value.target.value === 'date') {
     sort = 'date';
    }
    if (value.target.value === 'title') {
      sort = 'title';
    }
    if (value.target.value === 'rating') {
      sort = 'rating';
    }
    if (value.target.value === 'relevance') {
       sort = 'relevance';
    }
    if (value.target.value === 'videoCount') {
      sort = 'videoCount';
    }
    if (value.target.value === 'viewCount') {
       sort = 'viewCount';
    }
    this.router.navigate([url], {queryParams: {sort: sort}});
  }
  selectFromDate(value) {
    let url = `/video/search/${localStorage.getItem('keySearch')}`;
    this.fromDate = value.srcElement.value;
    if (this.toDate !== null) {
      this.router.navigate([url], {queryParams: {fromDate: this.fromDate, toDate: this.toDate}});
    }
  }
  selectToDate(value) {
    let url = `/video/search/${localStorage.getItem('keySearch')}`;
    this.toDate = value.srcElement.value;
    if (this.fromDate !== null) {
      this.router.navigate([url], {queryParams: {fromDate: this.fromDate, toDate: this.toDate}});
    }
  }
}
