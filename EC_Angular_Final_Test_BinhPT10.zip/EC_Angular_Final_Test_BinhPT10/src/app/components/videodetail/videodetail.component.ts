import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videodetail',
  templateUrl: './videodetail.component.html',
  styleUrls: ['./videodetail.component.css']
})
export class VideodetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
