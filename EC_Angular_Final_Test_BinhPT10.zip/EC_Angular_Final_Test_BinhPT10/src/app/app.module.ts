import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { SearchComponent } from './components/search/search.component';
import { VideoresultComponent } from './components/videoresult/videoresult.component';
import { VideolistComponent } from './components/videolist/videolist.component';
import { HttpClientModule } from '@angular/common/http';
import { VideodetailComponent } from './components/videodetail/videodetail.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'video',
    pathMatch: 'full'
  },
  {
    path: 'video',
    component: VideoresultComponent,
    children: [
      {
        path: 'search/:name',
        component: VideolistComponent
      }
    ]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    VideoresultComponent,
    VideolistComponent,
    VideodetailComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
