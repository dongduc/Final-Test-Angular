export class Snippet {
    channelId: string;
    title: string;
    thumbnails: string;
    description: string;
}