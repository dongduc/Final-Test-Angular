import { Snippet } from '../models/snippet.class';
export class Video {
    items: any = [
        {
            snippet: Snippet
        }
    ];
}