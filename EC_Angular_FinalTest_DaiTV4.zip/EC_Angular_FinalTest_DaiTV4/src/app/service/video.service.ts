import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VideoService {
  private url = 'https://www.googleapis.com/youtube/v3/';
  private key = 'AIzaSyAW43v2rMy_rnkARwFrct_5SUSAm4Eb-Xk';
  public pageSize = 5;
  constructor(private httpClient: HttpClient) {}

  getVideos(keySearch: string, maxResults: string, order: string) {
    return this.httpClient.get(this.url + 'search', {
      params: {
        part: 'snippet',
        q: keySearch,
        key: this.key,
        maxResults: maxResults,
        type: 'video',
        order: order
      }
    });
  }

  getVideoById(id: string) {
    return this.httpClient.get(this.url + 'videos', { params: {
      part: 'snippet,statistics',
      id: id,
      key: this.key
    }});
  }
}
