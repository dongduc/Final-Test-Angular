import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './search/search.component';
import { VideoSearchResultComponent } from './video-search-result/video-search-result.component';

const routes: Routes = [
  {path: '', redirectTo: '/search', pathMatch: 'full' },
  { path: 'search', component: SearchComponent, children: [
    { path: ':id', component: VideoSearchResultComponent }
  ] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
