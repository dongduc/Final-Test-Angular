export class Image {
    height: number;
    width: number;
    url: string;
}
