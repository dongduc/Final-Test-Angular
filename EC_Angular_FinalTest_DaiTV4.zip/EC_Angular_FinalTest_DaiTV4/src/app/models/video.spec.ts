import { Video } from './video';

describe('Video', () => {
  it('should create an instance', () => {
    expect(new Video()).toBeTruthy();
  });
});
