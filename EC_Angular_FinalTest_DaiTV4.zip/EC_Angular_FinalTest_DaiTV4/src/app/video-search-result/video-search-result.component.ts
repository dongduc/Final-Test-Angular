import { Component, OnInit } from '@angular/core';
import { VideoService } from '../service/video.service';
import { ActivatedRoute } from '@angular/router';
import { Video } from '../models/video';

@Component({
  selector: 'app-video-search-result',
  templateUrl: './video-search-result.component.html',
  styleUrls: ['./video-search-result.component.css']
})
export class VideoSearchResultComponent implements OnInit {
  public videos: Video[];
  public page = 1;
  constructor(
    private videoService: VideoService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.getVideos('relevance');
  }

  getVideos(order: string) {
    return this.activatedRoute.params.subscribe(params => {
      this.videoService.getVideos(params.id, '50', order).subscribe((data: {items: any[]}) => {
        this.videos = data.items;
      });
    });
  }

  etVideos(valueSort: string) {
    this.getVideos(valueSort);
  }
}
