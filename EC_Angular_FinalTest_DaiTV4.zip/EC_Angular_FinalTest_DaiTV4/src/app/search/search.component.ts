import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { VideoService } from '../service/video.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  constructor(
    private router: Router,
    private videoService: VideoService
  ) { }

  ngOnInit() {
  }

  onEnterSearch(keySearch) {
    this.router.navigateByUrl('search/' + keySearch);
  }

  onClickOk(pageNumber) {
    this.videoService.pageSize = +pageNumber;
  }
}
