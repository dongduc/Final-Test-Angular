import { Component, OnInit, Input } from '@angular/core';
import { VideoService } from '../service/video.service';
import { Item } from '../models/item';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-video-details',
  templateUrl: './video-details.component.html',
  styleUrls: ['./video-details.component.css']
})
export class VideoDetailsComponent implements OnInit {
  @Input()
  itemId: string;

  item: Item;
  urlVideo: SafeResourceUrl;
  constructor(
    private videoService: VideoService,
    private sanitizer: DomSanitizer,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.urlVideo = this.sanitizer.bypassSecurityTrustResourceUrl('');
  }
  ngOnInit() {
    this.getVideoDetail();
  }

  getVideoDetail() {
    return this.videoService
      .getVideoById(this.itemId)
      .subscribe((data: { items: any[] }) => {
        this.item = data.items[0];
        this.urlVideo = this.sanitizer.bypassSecurityTrustResourceUrl(
          'https://www.youtube.com/embed/' + this.item.id
        );
      });
  }
  onClose() {
    this.getVideoDetail();
  }
}
